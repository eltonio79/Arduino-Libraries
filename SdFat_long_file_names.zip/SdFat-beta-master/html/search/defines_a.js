var searchData=
[
  ['teensy3_5fsoft_5fspi',['TEENSY3_SOFT_SPI',['../_sd_fat_config_8h.html#a7e12956d7ec38c1dd9a27b9208e98fb8',1,'SdFatConfig.h']]]
];
